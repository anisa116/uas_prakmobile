package com.example.tutorial_darkmode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
