class Ramene{
  String description;
  String img_url;
  int price;
  String product_name;

Ramene(
  {
    required this.description,
    required this.img_url,
    required this.price,
    required this.product_name,
  });

  factory Ramene.fromJson(Map map){
    return Ramene(
      img_url: map['img_url'],
      description: map['description'],
      price: map['price'],
      product_name: map['product_name']
    );
  }
}