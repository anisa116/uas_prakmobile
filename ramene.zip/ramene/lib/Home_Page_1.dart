import 'package:flutter/material.dart';
import 'package:ramene/data/shared_pref.dart';
import 'package:ramene/onboarding_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'data/shared_pref.dart';

class Home_Page extends StatelessWidget {
   Home_Page({required this.name}); 
  String name;
 
  // Function setTheme;
 

  // bool isDarkmode = SharedPref.pref?.getBool('isDarkMode') ?? false;
  
  @override
     Widget build(BuildContext context) {
     
    // String isDarkMode = SharedPref.pref?.getString('ini darkmode') ?? "ini darkmode";
    // print(isDarkMode);
    // bool _gelap = false;
    // SharedPref _preferences = SharedPref();
    // bool get gelap => _gelap
    List <String> Gambar = [
      "1.png",
      "2.png",
      "3.png",
      "4.png",
      "5.png",
      "6.png",
    ];
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Home',
        textAlign: TextAlign.center,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.black
        ),),
        backgroundColor: Colors.amber,
        // leading: new IconButton(
        //   icon: new Icon(Icons.arrow_back_ios, color: Colors.amberAccent),
        //   onPressed: () {
        //     print('object');
        //     Navigator.of(context).pop();
        //   },
        // ),
        // actions: [
        //   Padding(padding: EdgeInsets.only(right: 20.0),
        //     child: ElevatedButton(
        //       onPressed: () {
        //   isDarkmode = !isDarkmode;
        //   widget.setTheme(isDarkmode);
        // },
        // child: const Text('Switch Theme'),
        //     ),
        //   )
        // ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.orange,
              ),
              child: Text('Ramene'),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: const Text('Home'),
              onTap: () => print('Tap Trash Menu')
            ),
            ListTile(
              leading: Icon(Icons.food_bank),
              title: const Text('Ramen'),
              onTap: () => print('Tap Trash Menu')
            ),
            new Divider(),
            ListTile(
               leading: Icon(Icons.exit_to_app),
               trailing: new Icon(Icons.cancel),
               title: const Text('LOGOUT'),
                 onTap: () {
                   Navigator.of(context).pop();
                   Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => OnboardingPage()));
                 }
             ),
          ],
        ),
      ),
      body: Column(
        children: [
          Text('Selamat Datang'),
          Text(name),
          Padding(padding: EdgeInsets.only(bottom: 15)),
          Container(
            width: 320,
            height: 45,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Color.fromARGB(255, 39, 40, 40),
                
                )
            ),
            child: TextField(
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20)
                ),
                hintText: 'Search',
              ),
            ),  
          ),

          const Padding(padding: EdgeInsets.all(10)),
          const Padding(
            padding: EdgeInsets.only(right: 230),
            child: Text('Top Menu',
            textAlign: TextAlign.center,
            style: 
            TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.black
            ),),
          ),

          Padding(padding: EdgeInsets.only(bottom: 5)),
          Expanded(
            child: GridView.builder(
              itemCount: Gambar.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
              itemBuilder: (context, i) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset('assets/grid/${Gambar[i]}'),
                );
              },
            )
          )
        ],
      ),

    //   bottomNavigationBar: BottomNavigationBar(
    //     items: const <BottomNavigationBarItem>[
    //       BottomNavigationBarItem(
    //         icon: Icon(Icons.home),
    //       ),
    //       BottomNavigationBarItem(
    //         icon: Icon(Icons.home),
    //       ),
    //       BottomNavigationBarItem(
    //         icon: Icon(Icons.home),
    //       ),
    //     ],
    //     currentIndex: 0,
    //     selectedItemColor: Color.fromARGB(255, 255, 166, 1),
    //     unselectedItemColor: Colors.grey,
    //     showUnselectedLabels: true
    // ),
    );
  }
}